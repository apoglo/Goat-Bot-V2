const axios = require('axios');
const jimp = require("jimp");
const fs = require("fs");

module.exports = {
  config: {
    name: "cover4",
    version: "1.0",
    author: "munem.",
    countDown: 10,
    role: 0,
    shortDescription: "Create fb Banner",
    longDescription: "",
    category: "image",
    guide: {
      en: "{p}{n}  Name or code | text | Text",
    }
  },

  onStart: async function ({ message, args, event, api }) {
    if (!args || args.length < 4) {
      return message.reply(`Please enter in the format:\n/avatar  Name or code | text | Text`);
    }

    const info = args.join(" ");
    const msg = info.split("|");

    const id = msg[0] ? msg[0].trim() : "";
    const name = msg[1] ? msg[1].trim() : "";
    const juswa = msg[2] ? msg[2].trim() : "";
    const bgtext = msg[3] ? msg[3].trim() : "";

    if (!id || !name || !juswa || !bgtext) {
      return message.reply("Please provide all the required information.");
    }

    await message.reply("Processing your cover senpai....");

    let img;
    if (isNaN(id)) { // If input is not a number
      let id1;
      try {
        id1 = (await axios.get(`https://www.nguyenmanh.name.vn/api/searchAvt?key=${id}`)).data.result.ID; 
      } catch (error) {
        await message.reply("Character not found, please check the name and try again...");
        return;
      }
      img = `https://www.nguyenmanh.name.vn/api/avtWibu?id=${id1}&chunen=${name}&chuky=${juswa}&apikey=APyDXmib`;
    } else {
      img = `https://www.nguyenmanh.name.vn/api/avtWibu?id=${id}&chunen=${name}&chuky=${juswa}&apikey=APyDXmib`;
    }

    const form = {
      body: "Your cover senpai"
    };
    form.attachment = [];
    form.attachment[0] = await global.utils.getStreamFromURL(img);
    message.reply(form);
  }
};