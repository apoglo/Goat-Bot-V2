const axios = require('axios');

module.exports = {
	config: {
		name: "fbv",
		aliases: ["fbvid"],
		version: "1.0",
		author: "JISHAN",
		countDown: 10,
		role: 0,
		shortDescription: "fb videos",
		longDescription: "download facebook video",
		category: "media",
		guide: "{pn} {{<link>}}"
	},

	onStart: async function ({ message, args }) {
		// Extract the video link from the command arguments
		const url = args.join(" ");
		if (!url)
			return message.reply(`Please enter video link`);
		else {
			// Construct the API URL with the video link
			const BASE_URL = `https://fbdownload.omgapi.repl.co/fbdownload?url=${encodeURIComponent(url)}`;

			await message.reply("Downloading Please Keep Patience");

			try {
				// Send a GET request to the API URL
				let res = await axios.get(BASE_URL);

				// Check if the API request was successful
				if (res.data.success) {
					// Extract the video URL from the response
					const videoUrl = res.data.result;

					// Download the video content as a stream
					const attachment = await getStreamFromURL(videoUrl);

					// Reply to the message with the video attachment
					await message.reply({
						body: 'Here\'s the Facebook video download:',
						attachment
					});
				} else {
					// Handle API error response
					await message.reply("Invalid link or video is not found");
				}
			} catch (e) {
				// Handle errors and reply with a "Not Found" message
				await message.reply("Error occurred while processing the request.");
				console.log(e);
			}
		}
	}
};

// Function to download the video content as a stream
async function getStreamFromURL(url) {
	try {
		const response = await axios({
			method: 'GET',
			url: url,
			responseType: 'stream'
		});
		return response.data;
	} catch (error) {
		console.error("Error while fetching video content:", error);
		throw error;
	}
}