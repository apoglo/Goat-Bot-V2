const axios = require('axios');
const fs = require('fs-extra');

module.exports = {
  config: {
    name: 'meme',
    aliases: ['memes'],
    author: 'JISHAN76',
    version: '1.0.0',
    role: 0,
    countdown: 5,
    shortDescription: { en: 'random meme' },
    longDescription: { en: 'random memes' },
    category: 'utility',
    guide: { en: '{pn} <Number>' }
  },

  onStart: async function ({ event, api, args }) {
    try {
      const response = await axios.get('https://www.nguyenmanh.name.vn/api/meme', {
        params: {
          apikey: 'APyDXmib'
        }
      });

      const memeUrl = response.data.result.url;
      const memeTitle = response.data.result.title;

      const callback = () => {
        api.sendMessage({
          body: `${memeTitle}`,
          attachment: fs.createReadStream(__dirname + '/tmp/meme.png')
        }, event.threadID, () => fs.unlinkSync(__dirname + '/tmp/meme.png'), event.messageID);
      };

      const writer = fs.createWriteStream(__dirname + '/tmp/meme.png');
      const imageResponse = await axios.get(memeUrl, { responseType: 'stream' });
      imageResponse.data.pipe(writer);
      writer.on('finish', callback);
    } catch (err) {
      console.log(err);
      return api.sendMessage('Error occurred while fetching a meme!', event.threadID);
    }
  }
};