const urban = require('urban');

module.exports = {
  config: {
    name: "slang",
    aliases: [],
    author: "munem",
    version: "1.0",
    countDown: 5,
    role: 0,
    shortDescription: "Generates a random slang word with its full form and meanings",
    longDescription: "Generates a random slang word with its full form and meanings",
    category: "language",
    guide: {
      vi: "{pn}",
      en: "{pn}"
    }
  },

  onStart: async function ({ message }) {
    try {
      const randomWord = urban.random();
      randomWord.first(async (word) => {
        if (!word) {
          return message.reply("No slang words found.");
        }

        const fullForm = word.word;
        const meanings = word.definition;

        const replyMessage = `Slang Word: ${fullForm}\nMeanings: ${meanings}`;
        return message.reply(replyMessage);
      });
    } catch (err) {
      console.error(err);
      return message.reply("An error occurred, please try again later");
    }
  }
};