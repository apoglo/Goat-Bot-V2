const axios = require("axios");
const fs = require("fs");

module.exports = {
  config: {
    name: "bard",
    version: "1.0",
    author: "JISHAN76",
    countDown: 5,
    role: 0,
    category: "ai",
    shortDescription: {
      en: "Unleash the power of bard!",
    },
    longDescription: {
      en: "Simply use the command: -bard",
    },
    category: "bard",
    guide: {
      en: "Unveil the magic of bard by using the command: {prefix}bard <prompt>",
    },
  },

  onStart: async function ({ api, event, args, message }) {
    const input = args.join(" ");
    if (!input) {
      message.reply("Please provide an input to get the output.");
      return;
    }

    try {
      const apiUrl = `https://bard.jishan10.repl.co/ask?input=${encodeURIComponent(input)}`;
      const response = await axios.get(apiUrl, { responseType: "json" });

      const { data } = response;
      const { content, image } = data;

      if (image && image.length > 0) {
        const imageUrl = image[0];
        const imageResponse = await axios.get(imageUrl, { responseType: "arraybuffer" });

        const imageBuffer = Buffer.from(imageResponse.data);
        const filePath = "image.jpg";

        fs.writeFileSync(filePath, imageBuffer);

        const attachment = fs.createReadStream(filePath);

        const replyMessage = {
          body: content,
          attachment,
        };

        message.reply(replyMessage, event.senderID);
      } else {
        message.reply(content, event.senderID);
      }
    } catch (error) {
      console.error(error);
      api.sendMessage(
        "Oh no! There seems to be an error on my quest to fetch the output. My apologies for the inconvenience. Please try again later.",
        event.senderID
      );
    }
  },
};
