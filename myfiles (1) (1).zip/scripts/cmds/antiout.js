const fs = require('fs');

module.exports = {
  config: {
    name: 'antiout',
    version: '1.0',
    author: 'JISHAN76',
    countDown: 5,
    role: 2,
    shortDescription: {
      en: 'Protect your group from members leaving',
    },
    longDescription: {
      en: 'The "antiout" command allows you to safeguard your group from members who leave unexpectedly. When activated, it automatically re-adds users who attempt to leave the group, ensuring that they stay connected and engaged. Prevent disruptions and foster a strong community with the "antiout" feature.',
    },
    category: 'Group Management',
    guide: {
      en: '/antiout on: activate antiout for this group\n/antiout off: deactivate antiout for this group\n/antiout check: check if antiout is activated for this group',
    },
  },
  langs: {
    en: {
      guide: "/antiout on|off|check"
    } 
  },

  onStart: async function ({
    api,
    args,
    event,
    threadsData,
    usersData,
    dashBoardData,
    globalData,
    threadModel,
    userModel,
    dashBoardModel,
    globalModel,
    role,
    commandName,
    getLang,
  }) {
    const groupId = event.threadID;
    const filePath = './allowed_group.json';

    if (args[0] === 'on') {
      const allowedGroups = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (!allowedGroups.includes(groupId)) {
        allowedGroups.push(groupId);
        fs.writeFileSync(filePath, JSON.stringify(allowedGroups));

        api.sendMessage(`Antiout has been successfully activated for this group. Thread ID: (${groupId})`, groupId);
      } else {
        api.sendMessage(`Antiout is already active for this group.`, groupId);
      }
    } else if (args[0] === 'off') {
      const allowedGroups = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (allowedGroups.includes(groupId)) {
        const newAllowedGroups = allowedGroups.filter((id) => id !== groupId);
        fs.writeFileSync(filePath, JSON.stringify(newAllowedGroups));

        api.sendMessage(`Antiout has been successfully deactivated for this group. Thread ID: (${groupId})`, groupId);
      } else {
        api.sendMessage(`Antiout is already inactive for this group.`, groupId);
      }
    } else if (args[0] === 'check') {
      const allowedGroups = JSON.parse(fs.readFileSync(filePath, 'utf8'));

      if (allowedGroups.includes(groupId)) {
        api.sendMessage(`Antiout is activated for this group.`, groupId);
      } else {
        api.sendMessage(`Antiout is not activated for this group.`, groupId);
      }
    } else {
      api.sendMessage(`Invalid command: ${getLang('guide')}`, groupId);
    }
  },

  onEvent: async function ({ event, api }) {
  if (event.logMessageType === 'log:unsubscribe') {
    const groupId = event.threadID;
    const userId = event.author;
    
    await api.addUserToGroup(userId, groupId);
    api.sendMessage(`User has been re-added to the group.`, groupId);
  }
},
};