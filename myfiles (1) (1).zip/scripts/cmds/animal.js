module.exports = {
  config: {
    name: "animalsound",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "JISHAN76",
    description: "Play animal sounds",
    commandCategory: "group",
    usages: "animalsound <animal>",
    cooldowns: 10,
  },

  onStart: async function ({ api, args, event }) {
    const animalSounds = {
      dog: "Woof!",
      cat: "Meow!",
      cow: "Moo!",
      duck: "Quack!",
      elephant: "Trumpet!",
    };

    const animal = args[0]?.toLowerCase();
    const sound = animalSounds[animal];

    if (sound) {
      api.sendMessage(`The ${animal} says "${sound}"`, event.threadID);
    } else {
      api.sendMessage(`Sorry, I don't know the sound of a ${animal}`, event.threadID);
    }
  }
};