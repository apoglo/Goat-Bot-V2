const axios = require('axios');
const fs = require('fs');

module.exports = {
  config: {
    name: "art",
    version: "1.1",
    author: "JISHAN",
    countDown: 5,
    role: 0,
    shortDescription: {
      en: "Save art to the filesystem"
    },
    longDescription: {
      en: "Save art to the filesystem by replying to an image with a custom prompt"
    },
    category: "tools",
    guide: {
      en: "Usage: -art <prompt>"
    }
  },

  onStart: async function ({ api, event, args }) {
    const linkanh = event.messageReply?.attachments[0]?.url;
    if (!linkanh) {
      return api.sendMessage('Please reply to an image.', event.threadID, event.messageID);
    }

    const prompt = args.join(" "); // Extract the user-provided prompt

    if (!prompt) {
      return api.sendMessage('Please provide a prompt after -art.', event.threadID, event.messageID);
    }

    try {
      const apiUrl = `https://www.annie-jarif.repl.co/jarif?imgurl=${encodeURIComponent(linkanh)}&prompt=${encodeURIComponent(prompt)}&apikey=anniejarif`;
      const response = await axios.get(apiUrl, { responseType: 'stream' });
      
      const fileName = 'art.jpg'; // You can choose a different name if needed
      const fileStream = fs.createWriteStream(fileName);
      
      response.data.pipe(fileStream);

      fileStream.on('finish', () => {
        return api.sendMessage({ body: 'Art saved!', attachment: fs.createReadStream(fileName) }, event.threadID, () => fs.unlinkSync(fileName));
      });
    } catch (error) {
      console.error(error);
      return api.sendMessage('Failed to save art.', event.threadID, event.messageID);
    }
  }
};