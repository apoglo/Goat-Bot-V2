const axios = require("axios");

module.exports = {
  config: {
    name: 'nezu',
    version: '1.0',
    author: 'JISHAN76',
    shortDescription: 'Chat with NEZU',
    category: 'funny',
    guide: {
      vi: '   {pn} <word>: chat with NEZU'
        + '\n   Ví dụ:\n    {pn} hi',
      en: '   {pn} <word>: chat with NEZU'
        + '\n   Example:\n    {pn} hi'
    }
  },

  langs: {
    vi: {
      chatting: 'Chatting with NEZU...',
      error: 'try different chat'
    },
    en: {
      chatting: 'Chatting with NEZU...',
      error: 'NEZU is currently unavailable. Please try again later.'
    }
  },

  onStart: async function ({ args, message, getLang }) {
    const yourMessage = args.join(" ");
    if (!yourMessage) {
      return message.reply("Yes, I'm active.");
    }

    try {
      const responseMessage = await getMessage(yourMessage);
      return message.reply(`${responseMessage}`);
    } catch (err) {
      console.log(err);
      return message.reply(getLang("error"));
    }
  }
};

async function getMessage(yourMessage) {
  const res = await axios.post(
    'https://api.simsimi.vn/v1/simtalk',
    new URLSearchParams({
      'text': yourMessage,
      'lc': 'bn'
    })
  );

  if (res.status > 200)
    throw new Error(res.data.success);

  return res.data.message;
}