const axios = require('axios');
const jimp = require("jimp");
const fs = require("fs");

module.exports = {
  config: {
    name: "cover2",
    version: "1.0",
    author: "JISHAN76",
    countDown: 10,
    role: 0,
    shortDescription: "Create fb Banner",
    longDescription: "",
    category: "image",
    guide: {
      en: "{p}{n}  Name or code | text | text",
    }
  },

  onStart: async function ({ message, args, event, api }) {
    if (!args || args.length < 3) {
      return message.reply(`Please enter in the format:\n/cover Name or code | text | text`);
    }

    const info = args.join(" ");
    const msg = info.split("|");

    const id = msg[0] ? msg[0].trim() : "";
    const name = msg[1] ? msg[1].trim() : "";
    const tenphu = msg[2] ? msg[2].trim() : "";

    if (!id || !name || !tenphu) {
      return message.reply("Please provide all the required information.");
    }

    await message.reply("Processing your cover senpai....");

    let img;
    if (isNaN(id)) { // If input is not a number
      let id1;
      try {
        id1 = (await axios.get(`https://www.nguyenmanh.name.vn/api/searchAvt?key=${id}`)).data.result.ID; 
      } catch (error) {
        await message.reply("Character not found, please check the name and try again...");
        return;
      }
      img = `https://www.nguyenmanh.name.vn/api/avtWibu4?id=${id1}&tenchinh=${name}&tenphu=${tenphu}&apikey=APyDXmib`;
    } else {
      img = `https://www.nguyenmanh.name.vn/api/avtWibu4?id=${id}&tenchinh=${name}&tenphu=${tenphu}&apikey=APyDXmib`;
    }

    const form = {
      body: "Your cover senpai"
    };
    form.attachment = [];
    form.attachment[0] = await global.utils.getStreamFromURL(img);
    message.reply(form);
  }
};