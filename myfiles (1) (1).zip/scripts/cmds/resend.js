const request = require("request");
const fs = require("fs");
const axios = require("axios");

function setResendCommandStatus(threadID, status) {
  const filePath = `./resend_command_status_${threadID}.json`;
  const data = {
    threadID,
    resendEnabled: status
  };
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = {
  config: {
    name: "resend",
    version: "1.0",
    author: "JISHAN76",
    countDown: 5,
    role: 1,
    shortDescription: "",
    longDescription: "",
    category: "GROUP",
  },

  onChat: async function ({ event, api, threadsData, usersData }) {
    const { writeFileSync, createReadStream } = require("fs");
    let { messageID, senderID, threadID, body: content } = event;
    if (!global.logMessage) global.logMessage = new Map();
    if (!global.data) global.data = {};
    if (!global.data.botID) global.data.botID = api.getCurrentUserID();

    const thread = (await threadsData.get(parseInt(threadID))) || {};

    if (typeof thread.resend !== "undefined" && thread.resend === false) return;

    if (senderID === global.data.botID) return;

    if (event.type !== "message_unsend") {
      global.logMessage.set(messageID, {
        msgBody: content,
        attachments: event.attachments,
      });
    }

    if (event.type === "message_unsend") {
      var getMsg = global.logMessage.get(messageID);
      if (!getMsg) return;

      const data = await usersData.get(senderID);
      const name = data ? data.name : "Unknown User";

      if (getMsg.attachments[0] === undefined) {
        api.sendMessage(`${name} removed this message: ${getMsg.msgBody}`, threadID);
      } else {
        let num = 0;
        let msg = {
          body: `${name} just removed ${getMsg.attachments.length} Attachment(s).${
            getMsg.msgBody !== "" ? `\nContent: ${getMsg.msgBody}` : ""
          }`,
          attachment: [],
          mentions: [{ tag: name, id: senderID }],
        };
        for (var i of getMsg.attachments) {
          num += 1;
          var getURL = await axios.get(i.url, { responseType: "stream" });
          var pathname = new URL(i.url).pathname;
          var ext = pathname.substring(pathname.lastIndexOf(".") + 1);
          var path = `./cache/${num}.${ext}`;
          getURL.data.pipe(fs.createWriteStream(path));
          msg.attachment.push(createReadStream(path));
        }
        api.sendMessage(msg, threadID);
      }
    }
  },

  onStart: async function ({ api, event, threadsData }) {
    const { threadID, messageID, body } = event;

    const thread = await threadsData.get(parseInt(threadID));
    if (typeof thread.resend === "undefined" || thread.resend !== false) {
      if (body === "-resend on") {
        setResendCommandStatus(threadID, true);
        return api.sendMessage("Successfully turned on resend command!", threadID, messageID);
      } else if (body === "-resend off") {
        setResendCommandStatus(threadID, false);
        return api.sendMessage("Successfully turned off resend command!", threadID, messageID);
      } else {
                const filePath = `./resend_command_status_${threadID}.json`;
        const resendCommandEnabled = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, "utf-8")).resendEnabled : false;
        const status = resendCommandEnabled ? "on" : "off";
        return api.sendMessage(`Resend command is currently ${status}. Use '-resend on' to enable or '-resend off' to disable.`, threadID, messageID);
      }
    }
  }
};