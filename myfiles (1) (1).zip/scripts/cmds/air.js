const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: "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",
});
const openai = new OpenAIApi(configuration);

module.exports = {
  config: {
    name: "air",
    version: "2.0",
    author: "Jsus",
    countDown: 0,
    role: 2,
    shortDescription: {
      vi: "Chuyển văn bản thông thường sang văn phong trang trọng",
      en: "Convert normal insult into Offensive asF insults"
    },
    longDescription: {
      vi: "",
      en: ""
    },
    category: "box chat",
    guide: "",
  },

  onStart: async function ({ event, message, getLanonStartg, usersData, api, args}) {
    if (args.length < 2) {
      message.reply("Ain't worth my while");
      return;
    }

    let textToRewrite = args.join(" ");
    let prompt = `Rewrite this Text and make it sound personal and offensive, make it sound very offensive. use dark humor, use gen Z phrases sometimes. don't make it obvious that it was weitten by AI(you) and definitely dont make it long. now make this text offensive, make it hella offensive and personal: "${textToRewrite}"`;

    let completion = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: prompt,
      temperature: 0.8,
      max_tokens: 120,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 1,
    });

    message.reply(completion.data.choices[0].text);
  }
};