const axios = require('axios');
const fs = require('fs-extra');

module.exports = {
  config: {
    name: 'pinterest',
    version: '1.0.0',
    hasPermission: 0,
    author: 'JISHAN76',
    description: 'Search and fetch images from Pinterest',
    category: 'image',
    usages: '<search query>',
    cooldowns: 5,
    dependencies: {},
  },

  onStart: async ({ api, event, args }) => {
    const searchQuery = args.join(' ');

    if (!searchQuery) {
      api.sendMessage('Please provide a search query.', event.threadID);
      return;
    }

    try {
      // Fetch Pinterest photos
      const apiUrl = `https://pinterest-api-one.vercel.app/?q=${encodeURIComponent(searchQuery)}`;
      const res = await axios.get(apiUrl);
      const data = res.data;

      if (!data.images || data.images.length === 0) {
        api.sendMessage('No images found for the provided search query.', event.threadID);
        return;
      }

      const images = data.images.slice(0, 9); // Limit to 15 images

      if (images.length === 0) {
        api.sendMessage('No images found for the provided search query.', event.threadID);
        return;
      }

      // Download and save the images
      const imagePaths = [];
      for (let i = 0; i < images.length; i++) {
        const imageUrl = images[i];

        const imagePath = __dirname + `/tmp/image_${i}.png`;
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data, 'binary'));

        imagePaths.push(imagePath);
      }

      // Create an array of attachments
      const attachments = imagePaths.map(imagePath => fs.createReadStream(imagePath));

      // Send message with the downloaded images as attachments
      await api.sendMessage(
        {
          attachment: attachments,
          body: `Images related to "${searchQuery}" from Pinterest`,
        },
        event.threadID
      );

      // Clean up the temporary image files
      for (let i = 0; i < imagePaths.length; i++) {
        fs.unlinkSync(imagePaths[i]);
      }

      // Send the output message
      api.sendMessage(` `, event.threadID);
    } catch (error) {
      console.error(error);
      api.sendMessage('An error occurred while fetching the images from Pinterest.', event.threadID);
    }
  },
};