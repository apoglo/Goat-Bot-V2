const axios = require('axios');

module.exports = {
  config: {
    name: "dog",
    version: "1.0",
    author: "JISHAN76",
    description: "Get a random dog image.",
    category: "Images"
  },

  onStart: async function ({ message }) {
    try {
      const dogAPI = 'https://random.dog/woof.json';

      const response = await axios.get(dogAPI);

      if (response.data && response.data.url) {
        const dogImageUrl = response.data.url;
        message.reply({
          body: "Here's a random dog image:",
          attachment: dogImageUrl
        });
      } else {
        message.reply("Couldn't fetch a random dog image right now. Please try again later.");
      }
    } catch (error) {
      console.error('Error:', error);
      message.reply('An error occurred while trying to fetch a random dog image. Please try again.');
    }
  }
};