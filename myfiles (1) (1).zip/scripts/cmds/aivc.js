const { Configuration, OpenAIApi } = require("openai");
const axios = require("axios");

const configuration = new Configuration({
  apiKey: "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",
});
const openai = new OpenAIApi(configuration);

module.exports = {
  config: {
    name: "aivc",
    version: "1.1",
    author: "cttro",
    countDown: 0,
    role: 2,
    shortDescription: {
      vi: "",
      en: ""
    },
    longDescription: {
      vi: "",
      en: ""
    },
    category: "box chat",
    guide: "",
  },

  onStart: async function ({ event, message, getLanonStartg, usersData, api, args}) {
    if (args.length < 2) {
      message.reply("Don't use AI for trivial things.");
      return;
    }

    let completion = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: args.join(" "),
      temperature: 0.9,
      max_tokens: 400,
      top_p: 1,
      frequency_penalty: 1,
      presence_penalty: 1,
    });

    const outputText = completion.data.choices[0].text;

    try {
      let url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=en&client=tw-ob&q=${outputText}`;
      const audioStream = await axios({
        method: "get",
        url: url,
        responseType: "stream"
      });

      message.reply({
        body: "",
        attachment: audioStream.data
      });
    } catch (e) {
      console.log(e);
      message.reply("Sorry, I'm unable to generate audio right now.");
    }
  }
};