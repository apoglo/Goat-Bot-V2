const axios = require('axios');
const fs = require('fs-extra');

module.exports = {
  config: {
    name: "write",
    version: "1.0",
    author: "JISHAN76",
    countDown: 10,
    role: 0,
    shortDescription: "Create writings",
    longDescription: "",
    category: "image",
    guide: {
      en: "{p}{n} text",
    }
  },

  onStart: async function ({ message, args, event, api }) {
    if (!args || args.length < 1) {
      return message.reply(`Please enter the text for the cover image.`);
    }

    const text = args.join(' '); // Combine all the elements in args into a single string

    const input = encodeURIComponent(text); // Encode the text input

    try {
      const response = await axios.get(`https://mfarels.my.id/api/magernulis2?text=${input}`, { responseType: 'arraybuffer' });

      const form = {
        body: "Your writing",
        attachment: []
      };

      const imageData = Buffer.from(response.data, 'binary');
      const filePath = 'cover_image.png';
      await fs.writeFile(filePath, imageData);

      form.attachment[0] = fs.createReadStream(filePath);
      await message.reply(form);

      await fs.remove(filePath); // Remove the temporary file
    } catch (error) {
      console.error(error);
      await message.reply("An error occurred while generating the cover image. Please try again later.");
    }
  }
};